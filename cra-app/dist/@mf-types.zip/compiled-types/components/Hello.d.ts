/// <reference types="react" />
interface Props {
    name: string;
}
declare const Hello: React.FC<Props>;
export default Hello;
