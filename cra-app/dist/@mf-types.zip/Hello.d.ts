export * from './compiled-types/components/Hello';
export { default } from './compiled-types/components/Hello';